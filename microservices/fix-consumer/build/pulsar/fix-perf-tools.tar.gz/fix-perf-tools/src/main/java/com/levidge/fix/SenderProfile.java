package com.levidge.fix;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class SenderProfile {
    public int rate;
    public int statRate;
    public int newPercentage;
    public int matchingPercentage;
    public int cancelPercentage;
    public boolean userDisconnect;
    public final List<FixInstrument> instruments = new ArrayList<>();
    public final List<FixUser> usersOM = new ArrayList<>();
    public final List<FixUser> usersMD = new ArrayList<>();

    public static int portOM;
    public static String hostOM;
    public static String targetCompIdOM;
    public static int portMD;
    public static String hostMD;
    public static String targetCompIdMD;

    public SenderProfile(final Properties properties, final List<String[]> usersList, final List<String[]> instrumentsList) {
        this.rate = Integer.parseInt(properties.getProperty("orders.rate"));
        this.statRate = Integer.parseInt(properties.getProperty("stats.rate"));
        this.newPercentage = Integer.parseInt(properties.getProperty("orders.newPercentage"));
        this.matchingPercentage = Integer.parseInt(properties.getProperty("orders.matchingPercentage"));
        this.cancelPercentage = Integer.parseInt(properties.getProperty("orders.cancelPercentage"));

        SenderProfile.portOM = Integer.parseInt(properties.getProperty("env.fixOM.port", "9880"));
        SenderProfile.hostOM = properties.getProperty("env.fixOM.host", "127.0.0.1");
        SenderProfile.targetCompIdOM = properties.getProperty("env.fixOM.targetCompId", "diginex");

        SenderProfile.portMD = Integer.parseInt(properties.getProperty("env.fixMD.port", "9880"));
        SenderProfile.hostMD = properties.getProperty("env.fixMD.host", "127.0.0.2");
        SenderProfile.targetCompIdMD = properties.getProperty("env.fixMD.targetCompId", "diginex_md");
        
        // populating users
        if (usersList.size() > 0) {
            for (String[] userDetails: usersList.subList(1, usersList.size())) {
                switch (userDetails[5]) {
                    case "3":
                        this.usersOM.add(new FixUser(userDetails, 1));
                        this.usersMD.add(new FixUser(userDetails, 2));
                        break;
                    case "1":
                        this.usersOM.add(new FixUser(userDetails, 1));
                        break;
                    case "2":
                        this.usersMD.add(new FixUser(userDetails, 2));
                        break;
                }
            }
        }

        if (instrumentsList.size() > 0) {
            for (String[] instrumentDetails: instrumentsList.subList(1, instrumentsList.size())) {
                this.instruments.add(new FixInstrument(instrumentDetails));
            }
        }


    }
}
