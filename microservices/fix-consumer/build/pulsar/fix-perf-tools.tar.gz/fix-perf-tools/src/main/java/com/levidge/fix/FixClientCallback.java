package com.levidge.fix;

import org.agrona.DirectBuffer;
import uk.co.real_logic.artio.messages.DisconnectReason;

public interface FixClientCallback {

    void onMessage(
            final FixClient client,
            final DirectBuffer buffer,
            final int offset,
            final int length,
            final long messageType,
            final long timestampInNs);

    void onReady(final FixClient client);

    void onDisconnect(final FixClient client, DisconnectReason reason);
}
