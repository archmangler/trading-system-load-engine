package com.levidge.fix;

import io.aeron.archive.Archive;
import io.aeron.archive.ArchiveThreadingMode;
import io.aeron.archive.ArchivingMediaDriver;
import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.agrona.IoUtil;
import org.agrona.concurrent.IdleStrategy;
import uk.co.real_logic.artio.CommonConfiguration;
import uk.co.real_logic.artio.engine.EngineConfiguration;
import uk.co.real_logic.artio.engine.FixEngine;
import uk.co.real_logic.artio.library.FixLibrary;
import uk.co.real_logic.artio.library.LibraryConfiguration;
import uk.co.real_logic.artio.library.SessionAcquiredInfo;
import uk.co.real_logic.artio.library.SessionHandler;
import uk.co.real_logic.artio.session.Session;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static java.util.Collections.singletonList;

@Log4j2
public class FixClientHandler {

    private final FixConfig config;
    private final EngineConfiguration configuration = new EngineConfiguration();
    private final MediaDriver.Context context = new MediaDriver.Context();
    private final Archive.Context archiveContext = new Archive.Context();
    private final LibraryConfiguration libraryConfiguration = new LibraryConfiguration();
    private final Map<String, FixClient> fixClients = new HashMap<>();
    private final Set<FixClient> inactiveClients = new HashSet<>();
    private final IdleStrategy idleStrategy = CommonConfiguration.backoffIdleStrategy();
    private ArchivingMediaDriver driver;
    private FixEngine engine;
    @Getter
    private FixLibrary library;

    FixClientHandler(FixConfig config) {
        this.config = config;
        init();
    }

    // Private
    public static void cleanupOldLogFileDir(final EngineConfiguration configuration) {
        IoUtil.delete(new File(configuration.logFileDir()), true);
    }

    private void init() {
        // Static configuration lasts the duration of a FIX-Gateway instance
        configuration.libraryAeronChannel(config.AERON_CHANNEL).logFileDir("client-logs");
        // .sessionPersistenceStrategy(alwaysPersistent()).logOutboundMessages(true);

        configuration
                .aeronArchiveContext()
                .aeronDirectoryName(config.AERON_DIR_NAME)
                .controlRequestChannel(config.CONTROL_REQUEST_CHANNEL)
                .controlResponseChannel(config.CONTROL_RESPONSE_CHANNEL);

        configuration.aeronContext().aeronDirectoryName(config.AERON_DIR_NAME);
        configuration.aeronContext().driverTimeoutMs(10000);

        context
                .threadingMode(ThreadingMode.SHARED)
                .dirDeleteOnStart(true)
                .aeronDirectoryName(config.AERON_DIR_NAME);

        archiveContext
                .threadingMode(ArchiveThreadingMode.SHARED)
                .deleteArchiveOnStart(true)
                .aeronDirectoryName(config.AERON_DIR_NAME)
                .archiveDirectoryName(config.ARCHIVE_DIR_NAME)
                .controlChannel(config.CONTROL_REQUEST_CHANNEL)
                .recordingEventsChannel(config.RECORDING_EVENTS_CHANNEL);

        libraryConfiguration
                .sessionAcquireHandler(this::onSessionAcquired)
                .libraryAeronChannels(singletonList(config.AERON_CHANNEL)).defaultHeartbeatIntervalInS(60);

        libraryConfiguration.aeronContext().aeronDirectoryName(config.AERON_DIR_NAME);
        libraryConfiguration.aeronContext().driverTimeoutMs(10000);

        cleanupOldLogFileDir(configuration);

        //libraryConfiguration.sessionCustomisationStrategy(sessionCustomisationStrategy)

        try {
            driver = ArchivingMediaDriver.launch(context, archiveContext);
            engine = FixEngine.launch(configuration);
            library = Util.blockingConnect(libraryConfiguration);
            log.debug("FixClientHandler init completed");
        } catch (Exception e) {
            log.error("Error while initializing FixClientHandler {}", e.getMessage());
            if (library != null) {
                library.close();
            }

            if (engine != null) {
                engine.close();
            }

            if (driver != null) {
                driver.close();
            }
        }
    }

    private SessionHandler onSessionAcquired(
            final Session session, final SessionAcquiredInfo acquiredInfo) {
        log.debug("onSessionAcquired. Session: {}, Info: {}", session.compositeKey(), acquiredInfo);
        String key = session.compositeKey().localCompId() + "_" + session.compositeKey().remoteCompId();
        FixClient client = fixClients.get(key);
        inactiveClients.add(client);
        return client;
    }

    public FixClient createClient(FixUser config, FixClientCallback callback) {
        String key = config.getCompId() + "_" + config.getTargetCompId();
        FixClient client = fixClients.get(key);
        if (client == null) {
            client = new FixClient(config, library, callback);
            fixClients.put(key, client);
        } else {
            // update config if required
            client.config(config);
        }

        if (!client.isConnected()) {
            client.connect();
        }

        return client;
    }

    public void poll(final int fragmentLimit) {
        int workPerformed = library.poll(fragmentLimit);

        // set active flag for clients
        updateClientStatus();
        // Idle

        idleStrategy.idle(workPerformed);
    }

    private void updateClientStatus() {
        inactiveClients.removeIf(FixClient::updateStatus);
    }

    public void stop() {
        if (library != null) {
            library.close();
        }

        if (engine != null) {
            engine.close();
        }

        if (driver != null) {
            driver.close();
        }
    }
}
