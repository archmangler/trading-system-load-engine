package com.levidge.fix;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.apache.commons.cli.*;
import org.apache.commons.configuration2.CompositeConfiguration;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ConfigurationConverter;
import org.apache.commons.configuration2.ex.ConfigurationException;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public final class RunTimeLauncher {

    private static final Options options = initOptions();
    private static final CommandLineParser commandLineParser = new DefaultParser();
    private static CommandLine commandLine;

    private static Options initOptions() {
        final Options options = new Options();

        options.addOption(Option.builder("h").longOpt("help").desc("Shows help").build());
        options.addOption(
                Option.builder("c")
                        .longOpt("config")
                        .desc("Configuration file to use.")
                        .hasArg()
                        .argName("file")
                        .build());
        options.addOption(
                Option.builder("u")
                        .longOpt("users")
                        .desc("Users to be used.")
                        .hasArg()
                        .argName("file")
                        .build());
        options.addOption(
                Option.builder("i")
                        .longOpt("instruments")
                        .desc("Instruments to be used.")
                        .hasArg()
                        .argName("file")
                        .build());
        options.addOption(
                Option.builder("t")
                        .longOpt("test-scenario")
                        .desc("What test to be run. Valid values are: \n\t[log, ord, mkt, both]")
                        .hasArg()
                        .argName("file")
                        .build());
        options.addOption(
                Option.builder("D")
                        .longOpt("override")
                        .hasArgs()
                        .valueSeparator()
                        .argName("property=value")
                        .desc("Configuration values to be overridden. These can be specified multiple times.")
                        .build());

        return options;
    }

    private static void printHelp() {
        // automatically generate the help statement
        final HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp(RunTimeLauncher.class.getName(), options, true);
    }

    private static List<String[]> readFromCsv(final CmdOptionValue optionValue, final boolean optional) throws IOException, CsvException {
        String csvPath = commandLine.getOptionValue(optionValue.getOption());
        if (!optional && !commandLine.hasOption(optionValue.getOption())) {
            printHelp();
            throw new IOException(optionValue.name() + " csv file path not given");
        } else if (!commandLine.hasOption(optionValue.getOption())) {
            return new ArrayList<>();
        }

        List<String[]> list;

        try (CSVReader reader = new CSVReader(new FileReader(csvPath))) {
            list = reader.readAll();
        }

        return list;
    }

    private static Configuration init(final String[] args) throws ParseException, IOException, ConfigurationException {

        commandLine = commandLineParser.parse(options, args);

        if (commandLine.hasOption("help")) {
            printHelp();
            return null;
        }

        if (!commandLine.hasOption("t")) {
            printHelp();
            throw new IOException("A test scenario is not specified");
        }

        return getCompositeConfiguration(commandLine);
    }

    private static CompositeConfiguration getCompositeConfiguration(final CommandLine commandLine)
            throws IOException {

        final CompositeConfiguration composite = new CompositeConfiguration();
        // Load user overrides
        final Configuration overrides =
                ConfigurationConverter.getConfiguration(commandLine.getOptionProperties("override"));
        composite.addConfiguration(overrides);

        // Load user provided config file
        String configFilePath = commandLine.getOptionValue("c");
        
        if (!commandLine.hasOption("c")) {
            printHelp();
            throw new IOException("Configuration file path not given");
        }

        // Load config config
        final Configuration finalConfig = loadConfig(configFilePath);
        composite.addConfiguration(finalConfig);

        return composite;
    }

    // Loads the configuration from the default properties file if it is not given
    // by user.
    static Configuration loadConfig(final String configFilePath) {
        final Properties properties = new Properties();

        try (InputStream input = new FileInputStream(configFilePath)) {
            properties.load(input);
        } catch (final IOException e) {
            System.out.println("Error loading config properties file.");
            return null;
        }

        final Configuration configuration = ConfigurationConverter.getConfiguration(properties);
        return configuration;
    }

    public static void main(final String[] args) {

        // init config and logging
        final Configuration configuration;

        final List<String[]> users;
        final List<String[]> instruments;

        try {
            configuration = init(args);
            users = readFromCsv(CmdOptionValue.USER, false);
            instruments = readFromCsv(CmdOptionValue.INSTRUMENT, true);
        } catch (final ParseException e) {
            System.out.println(e.getMessage());
            return;
        } catch (final ConfigurationException e) {
            System.out.println("Config Error: " + e.getMessage());
            return;
        } catch (final Exception e) {
            System.out.println("Error: " + e.getMessage());
            return;
        }

        try {
            run(configuration, users, instruments);
            System.exit(0);
        } catch (final Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Runs the fix gateway with the parameters specified
    private static void run(final Configuration config, final List<String[]> users, final List<String[]> instruments) throws NumberFormatException{
        // Create instance
        SenderProfile profile = new SenderProfile(ConfigurationConverter.getProperties(config), users, instruments);

        TestScenario testScenario = TestScenario.fromString(commandLine.getOptionValue("t"));
        final OrderSender orderSender = new OrderSender(profile, new FixConfig(), testScenario);
        orderSender.run();
        System.exit(0);
    }
}
