package com.levidge.fix;

import lombok.Value;

@Value
public class FixInstrument {
    String symbol;
    int instrumentId;
    int baseBuyPrice;
    int baseSellPrice;
    int priceVariation;
    int priceScale;
    int baseQuantity;
    int quantityVariation;
    int quantityScale;

    public FixInstrument(String[] instrumentDetails) {
        this.instrumentId = Integer.parseInt(instrumentDetails[0]);
        this.symbol = instrumentDetails[1];
        this.baseBuyPrice = Integer.parseInt(instrumentDetails[2]);
        this.baseSellPrice = Integer.parseInt(instrumentDetails[3]);
        this.priceVariation = Integer.parseInt(instrumentDetails[4]);
        this.priceScale = Integer.parseInt(instrumentDetails[5]);
        this.baseQuantity = Integer.parseInt(instrumentDetails[6]);
        this.quantityVariation = Integer.parseInt(instrumentDetails[7]);
        this.quantityScale = Integer.parseInt(instrumentDetails[8]);
    }
}
