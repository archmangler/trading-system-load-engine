#!/bin/bash

printf "Clearing old session tokens"
unset AWS_SESSION_TOKEN

printf "Setting AWS credentials for code artifacts ..."

export AWS_ACCESS_KEY_ID="AKIA5RBZWK24TZQ52KPA"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_REGION=ap-southeast-1

printf "exporting code artifact auth token ..."

export CODEARTIFACT_AUTH_TOKEN=$(aws codeartifact get-authorization-token --domain equos-maven --domain-owner 929981421241 --query authorizationToken --output text)

echo ${CODEARTIFACT_AUTH_TOKEN}

#printf "Running maven ..."
#mvn clean compile -DCODEARTIFACT_AUTH_TOKEN="${CODEARTIFACT_AUTH_TOKEN}"
