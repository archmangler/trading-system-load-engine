package com.levidge.fix;

public enum CmdOptionValue {
    USER("u"),
    INSTRUMENT("i");

    private final String option;

    public String getOption()
    {
        return this.option;
    }

    CmdOptionValue(String option)
    {
        this.option = option;
    }
}
