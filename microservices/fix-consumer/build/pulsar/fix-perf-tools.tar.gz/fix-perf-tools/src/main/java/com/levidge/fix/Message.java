package com.levidge.fix;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import uk.co.real_logic.artio.builder.Decoder;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@Log4j2
public class Message {
    private final Map<String, String> fields = new HashMap<>();
    @Getter
    private final String msgType;

    Message(final String msgType) {
        this.msgType = msgType;
    }

    public void set(String field, String value) {
        fields.put(field, value);
    }

    public String get(String field) {
        return fields.get(field);
    }

    public String entryAsAString(Entry<String, String> entry) {
        return String.format("\"%s\": \"%s\"", entry.getKey(), entry.getValue());
    }

    public boolean compare(Decoder receieved) {
        // First validate msgType
        String messageStr = receieved.toString();
        String msgTypeStr = String.format("\"MsgType\": \"%s\"", msgType);
        if (!messageStr.contains(msgTypeStr)) {
            log.debug(
                    "MsgType not matched. Expected={}, received={}",
                    msgTypeStr,
                    new String(receieved.header().msgType()));
            return false;
        }

        for (Entry<String, String> entry : fields.entrySet()) {
            if (!messageStr.contains(entryAsAString(entry))) {
                log.debug("Field {} not matched. Expected={}", entry.getKey(), entry.getValue());
                return false;
            }
        }

        return true;
    }

    public void reset(String field) {
        fields.remove(field);
    }
}
