package com.levidge.fix;

import lombok.Value;

@Value
public class FixUser {
    private final int compId;
    private final int id;
    private final String username;
    private String password;
    private boolean resetSeq = true;
    private boolean cancelOnDisconnect;
    private int accountId;
    private String host;
    private String targetCompId;
    private int port;
    private boolean isOMUser;

    FixUser(String[] userDetails, int mode) {
        this.id = Integer.parseInt(userDetails[0]);
        this.compId = 1_000_000_000 + Integer.parseInt(userDetails[0]);
        this.username = userDetails[1];
        this.password = userDetails[2];
        this.cancelOnDisconnect = Boolean.parseBoolean(userDetails[3]);
        this.accountId = Integer.parseInt(userDetails[4]);
        if (mode == 1) {
            this.port = SenderProfile.portOM;
            this.host = SenderProfile.hostOM;
            this.targetCompId = SenderProfile.targetCompIdOM;
            this.isOMUser = true;
        } else {
            this.port = SenderProfile.portMD;
            this.host = SenderProfile.hostMD;
            this.targetCompId = SenderProfile.targetCompIdMD;
            this.isOMUser = false;
        }
    }
}