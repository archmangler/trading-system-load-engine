package com.levidge.fix;

public enum TestScenario {
    ORDERS_ONLY("ord"),
    MARKET_DATA_ONLY("mkt"),
    LOGON_ONLY("log"),
    ORDERS_AND_MARKET_DATA("both");

    private final String option;

    public String getOption()
    {
        return this.option;
    }

    TestScenario(String option)
    {
        this.option = option;
    }

    public static TestScenario fromString(String text) {
        for (TestScenario testScenario : TestScenario.values()) {
            if (testScenario.option.equalsIgnoreCase(text)) {
                return testScenario;
            }
        }
        return null;
    }
}
