package com.levidge.fix;

public class FixConfig {
    public String AERON_DIR_NAME = "client-aeron";
    public String ARCHIVE_DIR_NAME = "client-aeron-archive";
    public String CONTROL_REQUEST_CHANNEL = "aeron:udp?endpoint=localhost:7011";
    public String CONTROL_RESPONSE_CHANNEL = "aeron:udp?endpoint=localhost:7021";
    public String RECORDING_EVENTS_CHANNEL = "aeron:udp?control-mode=dynamic|control=localhost:7031";
    public String AERON_CHANNEL = "aeron:udp?endpoint=localhost:10002";
}
