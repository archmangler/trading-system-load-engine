package com.levidge.fix;

import com.levidge.util.benchmark.LatencyDistributionBenchmark;
import lombok.extern.log4j.Log4j2;
import org.agrona.DirectBuffer;
import uk.co.real_logic.artio.*;
import uk.co.real_logic.artio.builder.*;
import uk.co.real_logic.artio.decoder.*;
import uk.co.real_logic.artio.fields.DecimalFloat;
import uk.co.real_logic.artio.messages.DisconnectReason;
import uk.co.real_logic.artio.util.AsciiBuffer;
import uk.co.real_logic.artio.util.MutableAsciiBuffer;

import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Log4j2
public class FixSender implements FixClientCallback {

    private final FixClient client;
    private final FixClientHandler handler;
    private final FixUser fixUser;
    private final ExecutionReportDecoder executionReport = new ExecutionReportDecoder();
    private final OrderCancelRejectDecoder cancelReject = new OrderCancelRejectDecoder();
    private final MarketDataSnapshotFullRefreshDecoder mdFull = new MarketDataSnapshotFullRefreshDecoder();
    private final MarketDataIncrementalRefreshDecoder mdIncr = new MarketDataIncrementalRefreshDecoder();
    private final NewOrderSingleEncoder newOrder = new NewOrderSingleEncoder();
    private final OrderCancelRequestEncoder cancelOrder = new OrderCancelRequestEncoder();
    private final OrderMassCancelRequestEncoder massCancel = new OrderMassCancelRequestEncoder();
    private final Random rand = new Random(0);
    private final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");
    private final Date date = new Date();
    private final AsciiBuffer string = new MutableAsciiBuffer();
    private final Printer printer = new PrinterImpl();
    private final LatencyDistributionBenchmark roundTripLatency = new LatencyDistributionBenchmark("RoundTripLatency", 1000);

    Set<String> pendingNew = new HashSet<>();
    Map<String, String> pendingCancel = new HashMap<>();
    Map<String, OpenOrder> openOrders = new HashMap<>();

    private String lastCancelOrderOrigClOrdID = "0_0_0";

    FixSender(FixUser fixUser, FixClientHandler handler) {
        this.handler = handler;
        this.client = handler.createClient(fixUser, this);
        this.fixUser = fixUser;
    }

    public FixUser getFixUser() {
        return this.fixUser;
    }

    @Override
    public void onMessage(
            FixClient client,
            DirectBuffer buffer,
            int offset,
            int length,
            long messageType,
            long timestampInNs) {

        final long msgInTime = System.currentTimeMillis();
        string.wrap(buffer);

//        log.info("FixSenderCallback OnMessage {}, Message {}", (char) messageType,
//                printer.toString(string, offset, length, messageType));

        if (messageType == ExecutionReportDecoder.MESSAGE_TYPE) {

            SenderStats.incrExecReportCount();
            executionReport.reset();
            executionReport.decode(string, offset, length);

            if (executionReport.execType() == ExecType.NEW.representation()) {

                if (!pendingNew.contains(executionReport.clOrdIDAsString())) {
                    log.debug("Ignoring unrelated NEW ExecutionReport message");
                    return;
                }
                final long sentTime = extractTime(executionReport.clOrdIDAsString());

                OpenOrder order = new OpenOrder(
                        executionReport.clOrdID(),
                        executionReport.orderID(),
                        executionReport.securityID(),
                        executionReport.side(),
                        executionReport.ordType(),
                        executionReport.orderQty(),
                        executionReport.price());

                pendingNew.remove(executionReport.clOrdIDAsString());
                openOrders.put(executionReport.clOrdIDAsString(), order);
//                log.debug("Latency is {} ms - sent time {}", (msgInTime - sentTime) , sentTime);
//                roundTripLatency.sample(msgInTime - sentTime);
                SenderStats.addNewOrderDelay(executionReport.clOrdIDAsString(), msgInTime - sentTime);

            } else if (executionReport.execType() == ExecType.CANCELED.representation()) {

                if (!pendingCancel.containsKey(executionReport.clOrdIDAsString())) {
                    log.debug("Ignoring unrelated CANCELED ExecutionReport message");
                    return;
                }
                final long sentTime = extractTime(pendingCancel.get(executionReport.clOrdIDAsString()));
                SenderStats.addCancelOrderDelay(executionReport.clOrdIDAsString(), msgInTime - sentTime);
                pendingCancel.remove(executionReport.clOrdIDAsString());
                openOrders.remove(executionReport.clOrdIDAsString());

            } else if (executionReport.ordStatus() == OrdStatus.FILLED.representation()
                    || executionReport.execType() == ExecType.DONE_FOR_DAY.representation()
                    || executionReport.execType() == ExecType.EXPIRED.representation()) {

                openOrders.remove(new String(executionReport.clOrdID()));

                String key = executionReport.securityIDAsString() + "_" + executionReport.price();
                if(SenderStats.pendingMDStats.containsKey(key)){
                    SenderStats.pendingMDStats.get(key).remove(executionReport.clOrdIDAsString());
                }

            } else if (executionReport.execType() == ExecType.REJECTED.representation()) {
                log.debug("Rejected. clOrdID: {}, Reason: {}", executionReport.clOrdIDAsString(), executionReport.textAsString());

                String key = executionReport.securityIDAsString() + "_" + executionReport.price();
                if(SenderStats.pendingMDStats.containsKey(key)){
                    SenderStats.pendingMDStats.get(key).remove(executionReport.clOrdIDAsString());
                }
                pendingNew.remove(executionReport.clOrdIDAsString());
            }

        } else if (messageType == OrderCancelRejectDecoder.MESSAGE_TYPE) {

            cancelReject.reset();
            cancelReject.decode(string, offset, length);

            log.debug("Cancel Rejected. clOrdID: {}, CxlRejReason: {}", cancelReject.clOrdIDAsString(), cancelReject.cxlRejReasonAsEnum());
//            pendingCancel.remove(executionReport.clOrdIDAsString());    // Does not work as origClOrdIDAsString() is as same as clOrdIDAsString()
            SenderStats.incrCancelRejectCount();

        } else if (messageType == MarketDataSnapshotFullRefreshDecoder.MESSAGE_TYPE) {
            mdFull.reset();
            mdFull.decode(string, offset, length);

            log.debug("MD full refresh. MDReqID: {}, Symbol: {}", mdFull.mDReqIDAsString(), mdFull.symbolAsString());
            final long sentTime = extractTime(mdFull.mDReqIDAsString());
            SenderStats.addMDFullRefreshDelay(mdFull.mDReqIDAsString(), msgInTime - sentTime);

        } else if (messageType == MarketDataIncrementalRefreshDecoder.MESSAGE_TYPE) {
            mdIncr.reset();
            mdIncr.decode(string, offset, length);
            SenderStats.incrMDIncrRefreshCount();

            String key = new String(mdIncr.mDEntriesGroup().securityID()) + "_" + mdIncr.mDEntriesGroup().mDEntryPx() ;
            if (SenderStats.pendingMDStats.containsKey(key)) {
                List<String> clOrdIDs = SenderStats.pendingMDStats.get(key);
                final long sentTime = extractTime(clOrdIDs.get(0));
                SenderStats.addMDIncrRefreshDelay(clOrdIDs.get(0), msgInTime - sentTime);
                clOrdIDs.remove(0);
                if (clOrdIDs.isEmpty()) {
                    SenderStats.pendingMDStats.remove(key);
                }
            }
        } else {

            // log.debug("FixSenderCallback OnMessage {}, Message {}", (char) messageType,
            // printer.toString(string, offset, length, messageType));
        }
    }

    @Override
    public void onReady(FixClient client) {
        log.debug("FixSenderCallback onReady");
    }

    @Override
    public void onDisconnect(FixClient client, DisconnectReason reason) {
        log.debug("FixSenderCallback onDisconnect {} ", reason.toString());
    }

    public boolean isReady() {
        return client.isReady();
    }

    public void sendMarketDataRequest(FixInstrument fixInstrument) {
        log.debug("Sending Market data request from user: {} for {}", fixUser.getId(), fixInstrument.getSymbol());
        MarketDataRequestEncoder marketDataRequestAll = MessageFactory.marketDataRequest(true, true, fixUser, fixInstrument);
        client.send(marketDataRequestAll);
    }

    public boolean sendNewOrder(FixInstrument instrument) {

        // log.debug("Sending new order");
        newOrder.reset();

        newOrder.clOrdID(fixUser.getCompId() + "_" + System.currentTimeMillis() + "_" + instrument.getInstrumentId());
        newOrder.account(String.valueOf(fixUser.getAccountId()).getBytes(StandardCharsets.UTF_8));
        newOrder.instrument().securityID(Integer.toString(instrument.getInstrumentId()));
        newOrder.instrument().securityIDSource(SecurityIDSource.EXCHANGE_SYMBOL);
        newOrder.side(Side.decode('1' + rand.nextInt(2)));
        newOrder.ordType(OrdType.LIMIT);

        if (newOrder.side() == '1') {
            newOrder.price(new DecimalFloat(instrument.getBaseBuyPrice() - rand.nextInt(instrument.getPriceVariation()), instrument.getPriceScale()));
        } else {
            newOrder.price(new DecimalFloat(instrument.getBaseSellPrice() + rand.nextInt(instrument.getPriceVariation()), instrument.getPriceScale()));
        }

        newOrder.orderQtyData().orderQty(new DecimalFloat(instrument.getBaseQuantity() + rand.nextInt(instrument.getQuantityVariation()), instrument.getQuantityScale()));
        newOrder.timeInForce(TimeInForce.DAY);
        newOrder.transactTime(dateFormat.format(date).getBytes());
        newOrder.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);

        client.send(newOrder);
        pendingNew.add(newOrder.clOrdIDAsString());

        String key = instrument.getInstrumentId() + "_" + newOrder.price();
        ArrayList<String> list = SenderStats.pendingMDStats.computeIfAbsent(key, k -> new ArrayList<>());
        list.add(newOrder.clOrdIDAsString());
        SenderStats.incrNewOrderCount();
//         printOrder(newOrder);
        return true;
    }

    public boolean sendMatchingPair(FixInstrument instrument) {

        // log.debug("Sending matching order pair");

        for (int i = 0; i < 2; i++) {
            newOrder.reset();

            newOrder.clOrdID(fixUser.getCompId() + "_" + System.currentTimeMillis() + "_" + instrument.getInstrumentId());
            newOrder.account(String.valueOf(fixUser.getAccountId()).getBytes(StandardCharsets.UTF_8));
            newOrder.instrument().securityID(Integer.toString(instrument.getInstrumentId()));
            newOrder.instrument().securityIDSource(SecurityIDSource.EXCHANGE_SYMBOL);
            newOrder.side(Side.decode('1' + i));
            newOrder.ordType(OrdType.LIMIT);
            newOrder.price(new DecimalFloat((instrument.getBaseBuyPrice() + instrument.getBaseSellPrice())/2, instrument.getPriceScale()));
            newOrder.orderQtyData().orderQty(new DecimalFloat(instrument.getBaseQuantity(), instrument.getPriceScale()));
            newOrder.timeInForce(TimeInForce.DAY);
            newOrder.transactTime(dateFormat.format(date).getBytes());
            newOrder.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);

            client.send(newOrder);
            pendingNew.add(newOrder.clOrdIDAsString());
            // printOrder(newOrder);
            String key = instrument.getInstrumentId() + "_" + newOrder.price();
            ArrayList<String> list = SenderStats.pendingMDStats.computeIfAbsent(key, k -> new ArrayList<>());
            list.add(newOrder.clOrdIDAsString());
        }
        SenderStats.incrMatchingPairCount();
        return true;
    }

    public boolean sendCancelOrder() {

        for (String origClOrdID : openOrders.keySet()) {
            if (extractTime(origClOrdID) > extractTime(lastCancelOrderOrigClOrdID)) {
                // log.debug("Sending cancel order");
                OpenOrder openOrder = openOrders.get(origClOrdID);
                lastCancelOrderOrigClOrdID = origClOrdID;

                cancelOrder.reset();

                cancelOrder.clOrdID(fixUser.getCompId() + "_" + System.currentTimeMillis() + "_" + openOrder.securityId);
                cancelOrder.account(String.valueOf(fixUser.getAccountId()).getBytes(StandardCharsets.UTF_8));
                cancelOrder.origClOrdID(openOrder.clOrdID);
                cancelOrder.orderID(openOrder.orderID);
                cancelOrder.instrument().securityID(openOrder.securityId);
                cancelOrder.instrument().securityIDSource(SecurityIDSource.EXCHANGE_SYMBOL);
                cancelOrder.side(openOrder.side);
                cancelOrder.orderQtyData().orderQty(openOrder.odrQty);
                cancelOrder.transactTime(dateFormat.format(date).getBytes());

                client.send(cancelOrder);
                SenderStats.incrCancelOrderCount();
                // printOrder(cancelOrder);
                pendingCancel.put(origClOrdID, cancelOrder.clOrdIDAsString());
                return true;
            }
        }
        return false;
    }

    public boolean sendMassCancelOrder() {      // Not supported by the FIX gateway yet
         log.debug("Sending mass cancel order");
        massCancel.reset();

        massCancel.clOrdID(fixUser.getCompId() + "_" + System.currentTimeMillis());
        massCancel.massCancelRequestType('7');
        massCancel.transactTime(dateFormat.format(date).getBytes());

        client.send(massCancel);
        return true;
    }

    private void printOrder(Encoder temp) {

        int type = (int) temp.messageType();
        NewOrderSingleEncoder newOrder;
        OrderCancelRequestEncoder cancelOrder;
        OrderCancelReplaceRequestEncoder cancelReplace;

        switch (type) {
            case 68:
                newOrder = (NewOrderSingleEncoder) temp;
                log.debug(
                        "New Order"
                                + "\nclOrdID: "
                                + newOrder.clOrdIDAsString()
                                + "\ninstrument: "
                                + newOrder.instrument().securityIDAsString()
                                + "\nside: "
                                + Side.decode(newOrder.side())
                                + "\nordType: "
                                + OrdType.decode(newOrder.ordType())
                                + "\nprice: "
                                + newOrder.price()
                                + "\norderQtyData: "
                                + newOrder.orderQtyData().orderQty()
                                + "\ntimeInForce: "
                                + TimeInForce.decode(newOrder.timeInForce())
                                + "\ntransactTime: "
                                + newOrder.transactTimeAsString()
                                + "\nhandlInst: "
                                + HandlInst.decode(newOrder.handlInst())
                                + "\n");
                break;
            case 70:
                cancelOrder = (OrderCancelRequestEncoder) temp;
                log.debug(
                        "Cancel Order"
                                + "\nclOrdID: "
                                + cancelOrder.clOrdIDAsString()
                                + "\norigClOrdID: "
                                + cancelOrder.origClOrdIDAsString()
                                + "\norderID: "
                                + cancelOrder.orderIDAsString()
                                + "\ninstrument: "
                                + cancelOrder.instrument().securityIDAsString()
                                + "\nside: "
                                + Side.decode(cancelOrder.side())
                                + "\norderQtyData: "
                                + cancelOrder.orderQtyData().orderQty()
                                + "\ntransactTime: "
                                + cancelOrder.transactTimeAsString()
                                + "\n");
                break;
        }
    }

    private long extractTime(String clOrdID) {
        return Long.parseLong(clOrdID.split("_")[1]);
    }

    private class OpenOrder {
        final String clOrdID;
        final String orderID;
        final String securityId;
        final Side side;
        final OrdType orderType;
        final DecimalFloat odrQty;
        final DecimalFloat price;

        private OpenOrder(
                char[] clOrdID,
                char[] orderID,
                char[] securityId,
                char side,
                char orderType,
                DecimalFloat orderQty,
                DecimalFloat price) {
            this.clOrdID = new String(clOrdID);
            this.orderID = new String(orderID);
            this.securityId = new String(securityId);
            this.side = Side.decode(side);
            this.orderType = OrdType.decode(orderType);
            this.odrQty = orderQty;
            this.price = price;
        }
    }
}
