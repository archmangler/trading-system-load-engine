package com.levidge.fix;

import io.aeron.logbuffer.ControlledFragmentHandler.Action;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.agrona.DirectBuffer;
import org.agrona.concurrent.SleepingIdleStrategy;
import uk.co.real_logic.artio.builder.Encoder;
import uk.co.real_logic.artio.library.*;
import uk.co.real_logic.artio.messages.DisconnectReason;
import uk.co.real_logic.artio.session.Session;

@Log4j2
public final class FixClient implements SessionHandler {

    private final FixUser config;
    private final FixLibrary library;
    private final FixClientCallback callback;
    private final SleepingIdleStrategy idleStrategy = new SleepingIdleStrategy(100);
    private Session session;

    @Getter
    private boolean ready = false;

    FixClient(FixUser config, FixLibrary library, FixClientCallback callback) {
        this.config = config;
        this.library = library;
        this.callback = callback;
    }

    public void connect() {
        final SessionConfiguration sessionConfig =
                SessionConfiguration.builder()
                        .address(config.getHost(), config.getPort())
                        .targetCompId(config.getTargetCompId())
                        .senderCompId(Integer.toString(config.getCompId()))
                        .resetSeqNum(config.isResetSeq())
                        .credentials(config.getUsername(), config.getPassword())
                        .build();

        session = LibraryUtil.initiate(library, sessionConfig, 3, idleStrategy);
        ready = false;
    }

    @Override
    public Action onMessage(
            DirectBuffer buffer,
            int offset,
            int length,
            int libraryId,
            Session session,
            int sequenceIndex,
            long messageType,
            long timestampInNs,
            long position,
            OnMessageInfo messageInfo) {
        // log.debug("onMessage {}", (char) messageType);
        callback.onMessage(this, buffer, offset, length, messageType, timestampInNs);
        return Action.CONTINUE;
    }

    @Override
    public void onTimeout(int libraryId, Session session) {
    }

    @Override
    public void onSlowStatus(int libraryId, Session session, boolean hasBecomeSlow) {
    }

    @Override
    public Action onDisconnect(int libraryId, Session session, DisconnectReason reason) {
        log.debug(
                "Session {} disconnected. Reason {}",
                session.compositeKey().localCompId(),
                reason.toString());
        callback.onDisconnect(this, reason);
        ready = false;
        session = null;
        return Action.CONTINUE;
    }

    @Override
    public void onSessionStart(Session session) {
        log.debug("Session started");
    }

    public void config(FixUser config2) {
    }

    public void disconnet() {
        if ((session != null) && (session.isActive() || session.isConnected())) {
            session.requestDisconnect();
        }
    }

    public boolean updateStatus() {
        if (session != null && session.canSendMessage()) {
            ready = true;
            callback.onReady(this);
            return true;
        }
        return false;
    }

    public boolean isConnected() {
        if (session != null) {
            return session.isConnected();
        }
        return false;
    }

    public void send(Encoder data) {
        if (session != null && ready) {
            if (session.send(data) < 0) {
                log.error("Failed to send message to {}", config.getCompId());
            }
        } else {
            log.warn("Failed to send message. Session {} is null or not ready", config.getCompId());
        }
    }

    public void sendRawData(DirectBuffer messageBuffer, final int offset, final int length, final int seqNum, final long messageType) {
        session.send(messageBuffer, offset, length, seqNum, messageType);
    }
}
