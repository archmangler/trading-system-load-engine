package com.levidge.fix;

import uk.co.real_logic.artio.*;
import uk.co.real_logic.artio.builder.*;
import uk.co.real_logic.artio.builder.MarketDataRequestEncoder.MDEntryTypesGroupEncoder;
import uk.co.real_logic.artio.decoder.ExecutionReportDecoder;
import uk.co.real_logic.artio.fields.DecimalFloat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MessageFactory {

    private static final Date date = new Date();
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");

    public static NewOrderSingleEncoder newBuyOrder() {
        NewOrderSingleEncoder newOrder = new NewOrderSingleEncoder();

        newOrder.clOrdID(String.valueOf(System.currentTimeMillis()));
        newOrder.instrument().symbol("ETH/BTC");
        newOrder.side(Side.BUY);
        newOrder.ordType(OrdType.LIMIT);
        newOrder.price(new DecimalFloat(125, 6));
        newOrder.orderQtyData().orderQty(new DecimalFloat(1, 2));
        newOrder.timeInForce(TimeInForce.GOOD_TILL_CANCEL);
        newOrder.transactTime(dateFormat.format(date).getBytes());
        newOrder.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        return newOrder;
    }

    public static NewOrderSingleEncoder newSellOrder() {
        NewOrderSingleEncoder newOrder = new NewOrderSingleEncoder();

        newOrder.clOrdID(String.valueOf(System.currentTimeMillis()));
        newOrder.instrument().symbol("ETH/BTC");
        newOrder.side(Side.SELL);
        newOrder.ordType(OrdType.LIMIT);
        newOrder.price(new DecimalFloat(126, 6));
        newOrder.orderQtyData().orderQty(new DecimalFloat(1, 2));
        newOrder.timeInForce(TimeInForce.GOOD_TILL_CANCEL);
        newOrder.transactTime(dateFormat.format(date).getBytes());
        newOrder.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        return newOrder;
    }

    public static NewOrderSingleEncoder newMarketOrder(final Side side, final long price, final long quantity) {
        NewOrderSingleEncoder newOrder = new NewOrderSingleEncoder();

        newOrder.clOrdID(String.valueOf(System.currentTimeMillis()));
        newOrder.instrument().symbol("ETH/USDT[F]");
        newOrder.side(side);
        newOrder.ordType(OrdType.MARKET);
        newOrder.price(new DecimalFloat(price, 1));
        newOrder.orderQtyData().orderQty(new DecimalFloat(quantity, 1));
        newOrder.timeInForce(TimeInForce.IMMEDIATE_OR_CANCEL);
        newOrder.transactTime(dateFormat.format(date).getBytes());
        newOrder.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        return newOrder;
    }

    public static OrderCancelRequestEncoder cancelOrder(ExecutionReportDecoder execReport) {
        OrderCancelRequestEncoder cancelOrder = new OrderCancelRequestEncoder();

        cancelOrder.clOrdID(String.valueOf(System.currentTimeMillis()));
        cancelOrder.origClOrdID(execReport.clOrdID());
        cancelOrder.orderID(execReport.orderID());
        cancelOrder.instrument().symbol(execReport.symbolAsString());
        cancelOrder.side(execReport.side());
        cancelOrder.orderQtyData().orderQty(execReport.orderQty());
        cancelOrder.transactTime(dateFormat.format(date).getBytes());

        return cancelOrder;
    }

    public static OrderCancelReplaceRequestEncoder cancelReplaceOrder(ExecutionReportDecoder execReport) {
        OrderCancelReplaceRequestEncoder replaceOrder = new OrderCancelReplaceRequestEncoder();

        replaceOrder.clOrdID(String.valueOf(System.currentTimeMillis()));
        replaceOrder.origClOrdID(execReport.clOrdID());
        replaceOrder.orderID(execReport.orderID());
        replaceOrder.instrument().symbol(execReport.symbolAsString());
        replaceOrder.side(execReport.side());
        DecimalFloat newQty = new DecimalFloat(execReport.orderQty().value() + 1, execReport.orderQty().scale());
        replaceOrder.orderQtyData().orderQty(execReport.orderQty());
        replaceOrder.orderQty2(newQty);
        replaceOrder.price(execReport.price());
        replaceOrder.price2(execReport.price());
        replaceOrder.transactTime(dateFormat.format(date).getBytes());
        replaceOrder.ordType(execReport.ordType());

        return replaceOrder;
    }

    public static SecurityListRequestEncoder securityListRequest() {
        SecurityListRequestEncoder securityListRequest = new SecurityListRequestEncoder();
        securityListRequest.securityReqID(Long.toString(System.currentTimeMillis()));
        securityListRequest.securityListRequestType(SecurityListRequestType.ALL_SECURITIES);
        return securityListRequest;
    }

    public static SecurityListRequestEncoder securityListRequestSingleInstrument() {
        SecurityListRequestEncoder securityListRequest = new SecurityListRequestEncoder();
        securityListRequest.securityReqID(Long.toString(System.currentTimeMillis()));
        securityListRequest.securityListRequestType(SecurityListRequestType.SYMBOL);
        securityListRequest.instrument().symbol("ETH/USDT[F]");
        return securityListRequest;
    }

    public static MarketDataRequestEncoder marketDataRequest(boolean orderBook, boolean trade, FixUser fixUser, FixInstrument fixInstrument) {
        MarketDataRequestEncoder marketDataRequest = new MarketDataRequestEncoder();

        int mdEntryTypeCount = 0;
        if (orderBook)
            mdEntryTypeCount += 2;
        if (trade)
            mdEntryTypeCount++;

        marketDataRequest.mDReqID(fixUser.getCompId() + "_" + System.currentTimeMillis()+ "_" + fixInstrument.getInstrumentId());
        marketDataRequest.subscriptionRequestType(SubscriptionRequestType.SNAPSHOT_PLUS_UPDATES);
        marketDataRequest.marketDepth(10);

        MDEntryTypesGroupEncoder mdEntryTypes = marketDataRequest.mDEntryTypesGroup(mdEntryTypeCount);
        if (orderBook) {
            mdEntryTypes.mDEntryType(MDEntryType.BID);
            mdEntryTypes = mdEntryTypes.next();
            mdEntryTypes.mDEntryType(MDEntryType.OFFER);
            if (trade) {
                mdEntryTypes = mdEntryTypes.next();
            }
        }

        if (trade) {
            mdEntryTypes.mDEntryType(MDEntryType.TRADE);
        }

        MarketDataRequestEncoder.RelatedSymGroupEncoder symGrp = marketDataRequest.relatedSymGroup(1);

        symGrp.instrument().securityID(String.valueOf(fixInstrument.getInstrumentId()));
        symGrp.instrument().securityIDSource(SecurityIDSource.EXCHANGE_SYMBOL);

        return marketDataRequest;

    }

    public static RequestForPositionsEncoder requestForPosition(String account, String symbol) {
        RequestForPositionsEncoder requestForPosition = new RequestForPositionsEncoder();
        requestForPosition.posReqID(String.valueOf(System.currentTimeMillis()));
        requestForPosition.posReqType(PosReqType.POSITIONS);
        requestForPosition.transactTime(dateFormat.format(date).getBytes());

        if (account != null) {
            requestForPosition.account(account);
        }

        if (symbol != null) {
            requestForPosition.instrument().symbol(symbol);
        }
        return requestForPosition;
    }
}
