package com.levidge.fix;

import lombok.extern.log4j.Log4j2;
import org.agrona.concurrent.SigInt;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

@Log4j2
public class OrderSender {

    private final SenderProfile profile;
    private final FixClientHandler handler;
    private final long MICRO_SECONDS_TO_SECOND = 1000000;
    private final int newRange;
    private final int matchingRange;
    private final int cancelRange;
    private final long gapBetweenTwoMessages;
    List<FixSender> sendersOM = new ArrayList<>();
    List<FixSender> sendersMD = new ArrayList<>(); 
    private long nextMsgSendTime;
    private long nexStatReportTime;
    private long startTime;
    private boolean sentMDRequest = false;
    private TestScenario testScenario;

    OrderSender(SenderProfile profile, FixConfig config, TestScenario testScenario) {
        this.profile = profile;
        this.handler = new FixClientHandler(config);
        this.startTime = System.nanoTime() / 1000;
        this.nexStatReportTime = System.currentTimeMillis() + 1000L * profile.statRate;
        this.gapBetweenTwoMessages = (MICRO_SECONDS_TO_SECOND / profile.rate);
        this.nextMsgSendTime = startTime + gapBetweenTwoMessages;
        this.newRange = profile.newPercentage;
        this.matchingRange = this.newRange + profile.matchingPercentage;
        this.cancelRange = this.matchingRange + profile.cancelPercentage;
        this.testScenario = testScenario;
    }

    public void run() {
        for (FixUser fixUser : profile.usersOM) {
            log.debug("{} connecting to {}:{}:{} - {}-{}", fixUser.getCompId(), fixUser.getHost(),
                    fixUser.getPort(), fixUser.getTargetCompId(), fixUser.getUsername(), fixUser.getPassword());
            sendersOM.add(new FixSender(fixUser, handler));
        }

        for (FixUser fixUser : profile.usersMD) {
            log.debug("{} connecting to {}:{}:{} - {}-{}", fixUser.getCompId(), fixUser.getHost(),
                    fixUser.getPort(), fixUser.getTargetCompId(), fixUser.getUsername(), fixUser.getPassword());
            
            sendersMD.add(new FixSender(fixUser, handler));
        }

        final AtomicBoolean running = new AtomicBoolean(true);
        SigInt.register(() -> running.set(false));

        boolean allReady = false;
        while (running.get()) {

            handler.poll(10);

            if (allReady) {
                if (profile.userDisconnect) {   // Exit the app once all the users connects successfully.
                    System.exit(0);
                }
                doWork();

            } else {
                allReady = checkClientsReadiness();
            }
        }
        SenderStats.exportStats();
    }

    private boolean checkClientsReadiness() {
        for (FixSender fixSender : sendersOM) {
            if (!fixSender.isReady()) {
                return false;
            }
        }
        log.debug("{} clients are ready", sendersOM.size());
        return true;
    }

    private void sendOrders() {
        long currentTime = System.nanoTime() / 1000;
        if (currentTime > nextMsgSendTime) {
            Random rand = new Random();
            boolean status;
            int senderIDIndex = rand.nextInt(sendersOM.size());
            int msgType = rand.nextInt(100);
            FixInstrument instrument = profile.instruments.get(rand.nextInt(profile.instruments.size()));

            if (msgType < this.newRange) {
                FixSender sender = sendersOM.get(senderIDIndex);
                status = sender.sendNewOrder(instrument);
            } else if (msgType < this.matchingRange) {
                status = sendersOM.get(senderIDIndex).sendMatchingPair(instrument);
            } else {  //cancel range
                status = sendersOM.get(senderIDIndex).sendCancelOrder();
            }
//            status = senders.get(senderIDIndex).sendMassCancelOrder();

            if (status) {
                nextMsgSendTime = currentTime + gapBetweenTwoMessages;
            }
        }
    }

    private void sendMarketDataRequests() {
        if (!sentMDRequest) {
            for (FixSender fixSender : sendersMD) {
                for (FixInstrument fixInstrument : profile.instruments) {
                    fixSender.sendMarketDataRequest(fixInstrument);
                }
            }
            sentMDRequest = true;
        }
    }

    private void doWork() {

        switch (testScenario) {
            case ORDERS_ONLY:
                //only send orders
                sendOrders();
                break;
            case MARKET_DATA_ONLY:
                //only send and receive market data
                sendMarketDataRequests();;
                break;
            case ORDERS_AND_MARKET_DATA:
                // send orders and also receive market data
                sendMarketDataRequests();;
                sendOrders();
                break;
            case LOGON_ONLY:
                //Only logons
                break;
        }

        if (System.currentTimeMillis() > nexStatReportTime) {
            SenderStats.printStatus(profile.statRate);
            SenderStats.resetStatus();
            // System.out.println((senders.get(senderIDIndex).openOrders.size()));
            nexStatReportTime = System.currentTimeMillis() + 1000L * profile.statRate;
        }
    }

    // public static void main(String[] args) {
    // Properties properties = loadConfig("config/config.properties");
    // SenderProfile profile = new SenderProfile(properties);

    // OrderSender sender = new OrderSender(profile, new FixConfig());
    // sender.run();
    // }
}
