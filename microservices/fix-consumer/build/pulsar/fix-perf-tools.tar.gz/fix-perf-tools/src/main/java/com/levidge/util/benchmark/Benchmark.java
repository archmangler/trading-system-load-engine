package com.levidge.util.benchmark;

import lombok.extern.log4j.Log4j2;

import java.text.NumberFormat;

@Log4j2
public class Benchmark {


    private final String name;
    private final NumberFormat format = NumberFormat.getInstance();

    protected Benchmark(final String name) {
        this.name = name;
        format.setGroupingUsed(true);
    }

    protected String format(final long value) {
        return format.format(value);
    }

    protected String format(final double value) {
        return format.format(value);
    }

    protected void log(final String message) {
        // if (log.isInfoEnabled()) {
        log.info("BENCHMARK {}: {}", name, message);
        // }
    }
}
