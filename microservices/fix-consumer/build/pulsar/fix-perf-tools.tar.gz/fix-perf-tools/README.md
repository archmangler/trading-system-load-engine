# Fix Gateway Performance Tester

The tool is capable of measuring end to end Fix message latencies. The tool can be used to test following scenarios.

1. Round trip time for New Order messages
   1. Send a new order message 
   2. Receive execution report and measure time
2. Round trip time for Cancel Order messages
   1. Send order cancel message
   2. Receive execution and measure time
3. Round trip time for Market Data Request messages
   1. Send Market Data Request message
   2. Receive Market Data Snapshot Full Refresh and measure time
4. Delay in receiving a Market Data Request message 
   1. Send a new order message
   2. Receive Market Data Incremental Refresh and measure time

## Prerequisites

Before you can run the tool and place orders, you have to a ssh tunnel between the local machine and the FIX gateway. You can create a secure tunnel using stunnel

`stunnel config/stunnel_config.cfg`

## Building the package

Simply build the package using maven commands.

`mvn clean package`

## Configs

A sample config file is provided in `config/config.properties` file
* Control the message sending rate
* Set the percentages of each message type
* Control the stat printing rate

## Running the tool

Tool can be executed by running the jar file. Run with `-h` for help.

`java -jar target/fix-client-1.0-SNAPSHOT.jar -c config/config.properties -u config/users.csv -i config/instruments.csv -t both`

Supported tet scenarios are as follows:
* log - log in the users and disconnect once all the users are logged in
* ord - log in the users and place orders
* mkt - log in the users and listen to market data
* both - log in the users and place orders while listening to market da

## Outputs

* A summery report will be printed every x seconds of time.
* A detailed report of all the individual message delays will be dumped upon the completion of each test to `latency.log` file. 