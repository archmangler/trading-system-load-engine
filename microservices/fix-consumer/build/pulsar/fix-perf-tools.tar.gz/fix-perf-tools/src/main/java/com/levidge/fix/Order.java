package com.levidge.fix;

import lombok.Value;
import uk.co.real_logic.artio.ExecType;
import uk.co.real_logic.artio.OrdStatus;
import uk.co.real_logic.artio.Side;
import uk.co.real_logic.artio.fields.DecimalFloat;

@Value
public class Order {
    String clOrdId;
    String symbol;
    Side side;
    DecimalFloat odrQty;
    DecimalFloat price;
    long orderId;
    ExecType execType;
    OrdStatus ordStatus;
}
