package com.levidge.fix;

import lombok.extern.log4j.Log4j2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Log4j2
public class SenderStats {

    private static int MessageTotal = 0;
    private static int newOrderTotal = 0;
    private static int matchingPairTotal = 0;
    private static int cancelOrderTotal = 0;
    private static int execReportTotal = 0;
    private static int cancelRejectTotal = 0;
    private static int mdIncrTotal = 0;
    private static double MessageRate = 0;
    private static double newOrderRate = 0;
    private static double matchingPairRate = 0;
    private static double cancelOrderRate = 0;
    private static double execReportRate = 0;
    private static double cancelRejectRate = 0;
    private static double mdIncrRate = 0;

    private static final Map<String, Long> newOrderDelays = new HashMap<>();
    private static final Map<String, Long> cancelOrderDelays = new HashMap<>();
    private static final Map<String, Long> mdFullDelays = new HashMap<>();
    private static final Map<String, Long> mdIncrDelays = new HashMap<>();

    public static final Map<String, ArrayList<String>> pendingMDStats = new HashMap<>();

    private static long minNewOrderDelay = Long.MAX_VALUE;
    private static long maxNewOrderDelay = Long.MIN_VALUE;
    private static long sumNewOrderDelay = 0;
    private static long newOrderCount = 0;

    private static long minCancelOrderDelay = Long.MAX_VALUE;
    private static long maxCancelOrderDelay = Long.MIN_VALUE;
    private static long sumCancelOrderDelay = 0;
    private static long cancelOrderCount = 0;

    private static long minMDFullDelay = Long.MAX_VALUE;
    private static long maxMDFullDelay = Long.MIN_VALUE;
    private static long sumMDFullDelay = 0;
    private static long mdFullCount = 0;

    private static long minMDIncrDelay = Long.MAX_VALUE;
    private static long maxMDIncrDelay = Long.MIN_VALUE;
    private static long sumMDIncrDelay = 0;
    private static long mdIncrCount = 0;

    public static void addNewOrderDelay(String clOrdID, long delay) {
        newOrderCount++;
        minNewOrderDelay = Math.min(delay, minNewOrderDelay);
        maxNewOrderDelay = Math.max(delay, maxNewOrderDelay);
        sumNewOrderDelay += delay;
        newOrderDelays.put(clOrdID, delay);
    }

    public static void addCancelOrderDelay(String clOrdID, long delay) {
        cancelOrderCount++;
        minCancelOrderDelay = Math.min(delay, minCancelOrderDelay);
        maxCancelOrderDelay = Math.max(delay, maxCancelOrderDelay);
        sumCancelOrderDelay += delay;
        cancelOrderDelays.put(clOrdID, delay);
    }

    public static void addMDFullRefreshDelay(String mdReqID, long delay) {
        mdFullCount++;
        minMDFullDelay = Math.min(delay, minMDFullDelay);
        maxMDFullDelay = Math.max(delay, maxMDFullDelay);
        sumMDFullDelay += delay;
        mdFullDelays.put(mdReqID, delay);
    }

    public static void addMDIncrRefreshDelay(String clOrdID, long delay) {
        mdIncrCount++;
        minMDIncrDelay = Math.min(delay, minMDIncrDelay);
        maxMDIncrDelay = Math.max(delay, maxMDIncrDelay);
        sumMDIncrDelay += delay;
        mdIncrDelays.put(clOrdID, delay);
    }

    public static void incrMessageCount() {
        MessageRate++;
        MessageTotal++;
    }

    public static void incrNewOrderCount() {
        newOrderRate++;
        newOrderTotal++;
        MessageRate++;
        MessageTotal++;
    }

    public static void incrMatchingPairCount() {
        matchingPairRate++;
        matchingPairTotal++;
        MessageRate += 2;
        MessageTotal += 2;
    }

    public static void incrCancelOrderCount() {
        cancelOrderRate++;
        cancelOrderTotal++;
        MessageRate++;
        MessageTotal++;
    }

    public static void incrExecReportCount() {
        execReportRate++;
        execReportTotal++;
    }

    public static void incrCancelRejectCount() {
        cancelRejectRate++;
        cancelRejectTotal++;
    }

    public static void incrMDIncrRefreshCount() {
        mdIncrRate++;
        mdIncrTotal++;
    }

    public static void resetStatus() {
        MessageRate = 0;
        newOrderRate = 0;
        matchingPairRate = 0;
        cancelOrderRate = 0;
        execReportRate = 0;
        cancelRejectRate = 0;
        mdIncrRate = 0;
        newOrderCount = 0;
        minNewOrderDelay = Long.MAX_VALUE;
        maxNewOrderDelay = Long.MIN_VALUE;
        sumNewOrderDelay = 0;
        cancelOrderCount = 0;
        minCancelOrderDelay = Long.MAX_VALUE;
        maxCancelOrderDelay = Long.MIN_VALUE;
        sumCancelOrderDelay = 0;
        minMDFullDelay = Long.MAX_VALUE;
        maxMDFullDelay = Long.MIN_VALUE;
        sumMDFullDelay = 0;
        mdFullCount = 0;
        minMDIncrDelay = Long.MAX_VALUE;
        maxMDIncrDelay = Long.MIN_VALUE;
        sumMDIncrDelay = 0;
        mdIncrCount = 0;
    }

    public static void printStatus(int statRate) {
        log.debug("Stat Update:"
                + "\n\t"
                + "Outgoing Message Rates (per second): " + "TotalMsgRate=" + (MessageRate / statRate) + ", New="
                + (newOrderRate / statRate) + ", Trades=" + (matchingPairRate / statRate) + ", Cancel="
                + (cancelOrderRate / statRate)
                + "\n\t"
                + "Incoming Message Rates (per second): ExecReport=" + (execReportRate / statRate)
                + ", CancelReject=" + (cancelRejectRate / statRate) + ", MDIncrUpdate=" + (mdIncrRate / statRate) + ", mdIncrCount=" + mdIncrCount
                + "\n\t"
                + "Outgoing Message Counts: " + "Total=" + MessageTotal + ", New=" + newOrderTotal + ", Trade="
                + matchingPairTotal + ", Cancel=" + cancelOrderTotal
                + "\n\t"
                + "Incoming message counts: ExecReport=" + execReportTotal
                + ", CancelReject=" + cancelRejectTotal + ", MDIncrUpdate=" + mdIncrTotal
                + "\n\t"
                + "NewOrder delays(ms): " + "Avg=" + (newOrderCount == 0 ? 0 : sumNewOrderDelay / newOrderCount)
                + ", Min=" + (minNewOrderDelay == Long.MAX_VALUE ? 0 : minNewOrderDelay)
                + ", Max=" + (maxNewOrderDelay == Long.MIN_VALUE ? 0 : maxNewOrderDelay)
                + "\n\t"
                + "CancelOrder delays(ms): " + "Avg=" + (cancelOrderCount == 0 ? 0 : sumCancelOrderDelay / cancelOrderCount)
                + ", Min=" + (minCancelOrderDelay == Long.MAX_VALUE ? 0 : minCancelOrderDelay)
                + ", Max=" + (maxCancelOrderDelay == Long.MIN_VALUE ? 0 : maxCancelOrderDelay)
                + "\n\t"
                + "MDFullRefresh delays(ms): " + "Avg=" + (mdFullCount == 0 ? 0 : sumMDFullDelay / mdFullCount)
                + ", Min=" + (minMDFullDelay == Long.MAX_VALUE ? 0 : minMDFullDelay)
                + ", Max=" + (maxMDFullDelay == Long.MIN_VALUE ? 0 : maxMDFullDelay)
                + "\n\t"
                + "MDIncrRefresh delays(ms): " + "Avg=" + (mdIncrCount == 0 ? 0 : sumMDIncrDelay / mdIncrCount)
                + ", Min=" + (minMDIncrDelay == Long.MAX_VALUE ? 0 : minMDIncrDelay)
                + ", Max=" + (maxMDIncrDelay == Long.MIN_VALUE ? 0 : maxMDIncrDelay)
        );

    }

    public static void exportStats() {
        try {
            BufferedWriter latencyFile = new BufferedWriter(new FileWriter("latency.log"));
            latencyFile.write("type, clOrdID/mdReqID, delay(ms)\n");
            for (Map.Entry<String, Long> delay : mdFullDelays.entrySet()) {
                latencyFile.write("MD_FULL, " + delay.getKey() + ", " + delay.getValue() + "\n");
            }
            for (Map.Entry<String, Long> delay : newOrderDelays.entrySet()) {
                latencyFile.write("NEW, " + delay.getKey() + ", " + delay.getValue() + "\n");
            }
            for (Map.Entry<String, Long> delay : cancelOrderDelays.entrySet()) {
                latencyFile.write("CANCELED, " + delay.getKey() + ", " + delay.getValue() + "\n");
            }
            for (Map.Entry<String, Long> delay : mdIncrDelays.entrySet()) {
                latencyFile.write("MD_INCR, " + delay.getKey() + ", " + delay.getValue() + "\n");
            }
            latencyFile.close();
            log.info("Latency file created");
        } catch (IOException e) {
            log.error("An error occurred.");
            e.printStackTrace();
        }
    }
}
