package com.levidge.fix;

import uk.co.real_logic.artio.library.FixLibrary;
import uk.co.real_logic.artio.library.LibraryConfiguration;

public final class Util {
    public static FixLibrary blockingConnect(final LibraryConfiguration configuration) {
        final FixLibrary library = FixLibrary.connect(configuration);
        while (!library.isConnected()) {
            library.poll(1);
            Thread.yield();
        }
        return library;
    }
}
