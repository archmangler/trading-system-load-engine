#!/bin/bash

set -e

mvn clean -DskipTests package

cd target

if [ -d dist ]; then 
    echo "Removing dist"
    rm dist
fi

mkdir dist
cp -rv lib dist
cp -v *.jar dist
cp -rv ../config dist/

cd ..
